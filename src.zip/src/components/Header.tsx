'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function Header() {
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="bg-purple-900 text-white p-4">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <Link href="/" className="flex items-center mb-4 md:mb-0">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center mr-2">
            <span className="text-purple-900 text-2xl font-bold">G</span>
          </div>
          <h1 className="text-2xl font-bold">趣味游戏网</h1>
        </Link>
        
        <form onSubmit={handleSearch} className="w-full md:w-1/2 flex">
          <input
            type="text"
            placeholder="搜索游戏..."
            className="w-full px-4 py-2 rounded-l-lg text-black focus:outline-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button 
            type="submit" 
            className="bg-purple-700 px-4 py-2 rounded-r-lg hover:bg-purple-600 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </form>
      </div>
    </header>
  );
} 