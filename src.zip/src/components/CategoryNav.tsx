import Link from 'next/link';
import { categories } from '@/lib/data';

export default function CategoryNav() {
  return (
    <nav className="bg-gray-800 text-white">
      <div className="container mx-auto px-4">
        <ul className="flex flex-wrap">
          {categories.map((category) => (
            <li key={category.id} className="mr-1">
              <Link 
                href={`/category/${category.slug}`}
                className="inline-block py-3 px-4 hover:bg-purple-700 transition-colors"
              >
                {category.name}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
} 