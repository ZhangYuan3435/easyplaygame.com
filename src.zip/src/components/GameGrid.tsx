import { Game } from '@/lib/types';
import GameCard from './GameCard';

interface GameGridProps {
  games: Game[];
  title?: string;
}

export default function GameGrid({ games, title }: GameGridProps) {
  return (
    <section className="py-8">
      {title && (
        <h2 className="text-2xl font-bold mb-6 px-4">{title}</h2>
      )}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 px-4">
        {games.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>
    </section>
  );
} 