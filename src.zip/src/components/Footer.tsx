import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">趣味游戏网</h3>
            <p className="text-gray-300">
              收集各种有趣的开源网页游戏，为您提供轻松愉快的游戏体验。
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">游戏分类</h3>
            <ul className="space-y-2">
              <li><Link href="/category/shooting" className="text-gray-300 hover:text-white">射击游戏</Link></li>
              <li><Link href="/category/tower-defense" className="text-gray-300 hover:text-white">塔防游戏</Link></li>
              <li><Link href="/category/puzzle" className="text-gray-300 hover:text-white">益智游戏</Link></li>
              <li><Link href="/category/racing" className="text-gray-300 hover:text-white">赛车游戏</Link></li>
              <li><Link href="/category/adventure" className="text-gray-300 hover:text-white">冒险游戏</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">关于我们</h3>
            <p className="text-gray-300">
              我们致力于收集高质量开源网页游戏，让玩家可以随时随地享受游戏乐趣。
            </p>
            <p className="text-gray-300 mt-2">
              所有游戏均来自开源社区，感谢游戏开发者的贡献！
            </p>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} 趣味游戏网. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  );
} 