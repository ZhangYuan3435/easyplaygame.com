import Image from 'next/image';
import Link from 'next/link';
import { Game } from '@/lib/types';

interface GameCardProps {
  game: Game;
}

export default function GameCard({ game }: GameCardProps) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
      <div className="relative h-48 bg-gray-200">
        <Image
          src={game.thumbnailUrl}
          alt={game.title}
          className="object-cover"
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          priority={false}
        />
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{game.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {game.description}
        </p>
        <Link
          href={`/game/${game.id}`}
          className="inline-block bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition-colors"
        >
          开始游戏
        </Link>
      </div>
    </div>
  );
} 