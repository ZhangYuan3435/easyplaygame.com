import Header from '@/components/Header';
import CategoryNav from '@/components/CategoryNav';
import GameGrid from '@/components/GameGrid';
import Footer from '@/components/Footer';
import { games } from '@/lib/data';

export default function SearchPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const query = typeof searchParams.q === 'string' ? searchParams.q.toLowerCase() : '';
  
  // 根据搜索词过滤游戏
  const filteredGames = games.filter((game) => {
    return (
      game.title.toLowerCase().includes(query) ||
      game.description.toLowerCase().includes(query) ||
      game.categories.some((category) => category.toLowerCase().includes(query))
    );
  });

  return (
    <main>
      <Header />
      <CategoryNav />
      
      <div className="container mx-auto py-6">
        <section className="px-4 mb-6">
          <h1 className="text-3xl font-bold mb-2">搜索结果</h1>
          <p className="text-gray-600">
            搜索 "{query}" 的结果，共找到 {filteredGames.length} 个游戏
          </p>
        </section>
        
        {filteredGames.length > 0 ? (
          <GameGrid games={filteredGames} />
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-semibold text-gray-500">未找到结果</h2>
            <p className="mt-2 text-gray-400">
              抱歉，没有找到与 "{query}" 相关的游戏，请尝试其他关键词。
            </p>
          </div>
        )}
      </div>
      
      <Footer />
    </main>
  );
} 