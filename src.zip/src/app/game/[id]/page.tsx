import { notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { getGameById } from '@/lib/data';
import Header from '@/components/Header';
import CategoryNav from '@/components/CategoryNav';
import Footer from '@/components/Footer';
import GameView from '@/components/GameView';

export default function GamePage({ params }: { params: { id: string } }) {
  const game = getGameById(params.id);
  
  if (!game) {
    notFound();
  }

  return (
    <main>
      <Header />
      <CategoryNav />
      
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{game.title}</h1>
          <Link 
            href="/" 
            className="text-purple-600 hover:text-purple-800 transition-colors inline-flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            返回首页
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <GameView game={game} />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-2">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4">游戏介绍</h2>
              <p className="text-gray-700 mb-6">{game.description}</p>
              
              <h2 className="text-2xl font-bold mb-4">操作说明</h2>
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <p className="text-gray-700">{game.instructions}</p>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">游戏信息</h2>
              <div className="relative h-36 mb-4 bg-gray-200 rounded overflow-hidden">
                <Image
                  src={game.thumbnailUrl}
                  alt={game.title}
                  className="object-cover"
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="mb-4">
                <h3 className="font-semibold text-gray-700">游戏来源</h3>
                <a 
                  href={game.sourceUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-purple-600 hover:text-purple-800 transition-colors"
                >
                  访问源码仓库
                </a>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">游戏分类</h3>
                <div className="flex flex-wrap gap-2">
                  {game.categories.map(categoryId => (
                    <Link
                      key={categoryId}
                      href={`/category/${categoryId}`}
                      className="inline-block bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm hover:bg-purple-100 transition-colors"
                    >
                      {categoryId === 'shooting' ? '射击游戏' : 
                       categoryId === 'tower-defense' ? '塔防游戏' : 
                       categoryId === 'puzzle' ? '益智游戏' : 
                       categoryId === 'racing' ? '赛车游戏' : 
                       categoryId === 'adventure' ? '冒险游戏' : categoryId}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </main>
  );
} 