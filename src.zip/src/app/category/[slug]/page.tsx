import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import CategoryNav from '@/components/CategoryNav';
import GameGrid from '@/components/GameGrid';
import Footer from '@/components/Footer';
import { getGamesByCategory, categories } from '@/lib/data';

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const category = categories.find(cat => cat.slug === params.slug);
  
  if (!category) {
    notFound();
  }
  
  const games = getGamesByCategory(category.id);

  return (
    <main>
      <Header />
      <CategoryNav />
      
      <div className="container mx-auto py-6">
        <section className="px-4 mb-6">
          <h1 className="text-3xl font-bold mb-2">{category.name}</h1>
          <p className="text-gray-600">
            {category.description}
          </p>
        </section>
        
        {games.length > 0 ? (
          <GameGrid games={games} />
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-semibold text-gray-500">暂无游戏</h2>
            <p className="mt-2 text-gray-400">该分类下暂时没有游戏，请稍后再来看看！</p>
          </div>
        )}
      </div>
      
      <Footer />
    </main>
  );
} 