import Header from '@/components/Header';
import CategoryNav from '@/components/CategoryNav';
import GameGrid from '@/components/GameGrid';
import Footer from '@/components/Footer';
import { games, categories } from '@/lib/data';
import { getGamesByCategory } from '@/lib/data';

export default function Home() {
  // 获取每个分类的前4个游戏
  const featuredGames = games.slice(0, 4);
  const gamesByCategory = categories.map(category => ({
    category,
    games: getGamesByCategory(category.id).slice(0, 2) // 每个分类展示2个游戏
  }));

  return (
    <main>
      <Header />
      <CategoryNav />
      
      <div className="container mx-auto py-6">
        <section className="px-4">
          <h1 className="text-3xl font-bold mb-2">欢迎来到趣味游戏网</h1>
          <p className="text-gray-600 mb-8">
            在这里你可以找到各种好玩的开源网页游戏，随时随地畅玩！
          </p>
        </section>
        
        <GameGrid games={featuredGames} title="推荐游戏" />
        
        {gamesByCategory.map(({ category, games }) => (
          <GameGrid 
            key={category.id} 
            games={games} 
            title={category.name} 
          />
        ))}
      </div>
      
      <Footer />
    </main>
  );
} 