export interface Game {
  id: string;
  title: string;
  description: string;
  instructions: string;
  thumbnailUrl: string;
  sourceUrl: string;
  categories: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
} 