import { Game, Category } from './types';

export const categories: Category[] = [
  {
    id: 'shooting',
    name: '射击游戏',
    slug: 'shooting',
    description: '考验你的瞄准和反应能力的射击类游戏'
  },
  {
    id: 'tower-defense',
    name: '塔防游戏',
    slug: 'tower-defense',
    description: '策略性的防御和资源管理游戏'
  },
  {
    id: 'puzzle',
    name: '益智游戏',
    slug: 'puzzle',
    description: '锻炼你的大脑和思维能力的益智类游戏'
  },
  {
    id: 'racing',
    name: '赛车游戏',
    slug: 'racing',
    description: '紧张刺激的速度与激情'
  },
  {
    id: 'adventure',
    name: '冒险游戏',
    slug: 'adventure',
    description: '探索未知世界的冒险类游戏'
  }
];

export const games: Game[] = [
  {
    id: 'space-shooter',
    title: '太空射手',
    description: '一款经典的太空射击游戏，你需要控制飞船躲避障碍物并射击敌人。游戏难度随时间增加，考验你的反应能力和操作技巧。',
    instructions: '使用WASD或方向键控制飞船移动，空格键发射子弹。收集道具可以增强武器或获得护盾保护。',
    thumbnailUrl: '/images/space-shooter.jpg',
    sourceUrl: 'https://github.com/lostgarden/spaceShooter',
    categories: ['shooting']
  },
  {
    id: 'zombie-shooter',
    title: '僵尸射击',
    description: '在僵尸末日中存活下来！这款第一人称射击游戏让你体验紧张刺激的僵尸围城。收集武器和弹药，尽可能地存活更久。',
    instructions: '使用鼠标瞄准和射击，WASD移动角色，R键装弹，F键使用物品。注意弹药管理和掩护。',
    thumbnailUrl: '/images/zombie-shooter.jpg',
    sourceUrl: 'https://github.com/freedomdan/zombie-defense',
    categories: ['shooting']
  },
  {
    id: 'castle-defense',
    title: '城堡守卫',
    description: '保卫你的城堡免受敌人入侵！这款经典塔防游戏让你建造不同类型的防御塔来阻止敌人到达你的基地。',
    instructions: '点击地图上的位置建造防御塔。不同的塔有不同的攻击方式和范围。升级塔可以提高其性能。合理规划资源分配。',
    thumbnailUrl: '/images/castle-defense.jpg',
    sourceUrl: 'https://github.com/towerdefense/castle-td',
    categories: ['tower-defense']
  },
  {
    id: 'alien-invasion',
    title: '外星入侵',
    description: '阻止外星人入侵地球！这款塔防游戏有独特的科幻主题和多样化的防御选择。',
    instructions: '拖放防御塔到地图上的格子中。每个防御塔都有特殊能力，可以右键点击激活。完成波次获得资源用于购买更多防御塔。',
    thumbnailUrl: '/images/alien-invasion.jpg',
    sourceUrl: 'https://github.com/alienDefense/invasion-td',
    categories: ['tower-defense']
  },
  {
    id: 'color-match',
    title: '颜色匹配',
    description: '一款简单但上瘾的益智游戏，你需要将相同颜色的方块连接起来清除它们。每个关卡都有不同的目标和限制。',
    instructions: '点击并拖动相同颜色的方块以连接它们。需要至少3个相连的方块才能消除。尝试创建特殊组合以获得额外加分。',
    thumbnailUrl: '/images/color-match.jpg',
    sourceUrl: 'https://github.com/puzzlegames/color-matcher',
    categories: ['puzzle']
  },
  {
    id: 'brain-teaser',
    title: '脑力挑战',
    description: '挑战你的逻辑思维和解谜能力的一系列关卡。每个关卡都提供不同类型的谜题，从逻辑推理到空间思维。',
    instructions: '仔细阅读每个关卡的说明。点击、拖动或输入来解决谜题。有些关卡可能需要发现隐藏的线索或模式。',
    thumbnailUrl: '/images/brain-teaser.jpg',
    sourceUrl: 'https://github.com/logicpuzzles/brainteaser',
    categories: ['puzzle']
  },
  {
    id: 'speed-racer',
    title: '极速赛车手',
    description: '体验高速赛车的刺激！这款赛车游戏拥有精美的3D图形和物理引擎，让驾驶体验更加真实。',
    instructions: '使用方向键或WASD控制车辆。空格键为刹车，Shift键为加速。在弯道前减速以避免打滑，直道上尽可能加速。',
    thumbnailUrl: '/images/speed-racer.jpg',
    sourceUrl: 'https://github.com/racegames/speedracer',
    categories: ['racing']
  },
  {
    id: 'kart-racing',
    title: '卡丁车竞赛',
    description: '一款有趣的卡通风格卡丁车竞速游戏，适合所有年龄段的玩家。收集道具，使用特殊能力超越对手！',
    instructions: '方向键控制方向，空格键使用收集到的道具。尝试利用弯道内侧加速，避开障碍物获得更好的成绩。',
    thumbnailUrl: '/images/kart-racing.jpg',
    sourceUrl: 'https://github.com/kartgame/funracer',
    categories: ['racing']
  },
  {
    id: 'treasure-hunt',
    title: '寻宝冒险',
    description: '踏上寻找失落宝藏的冒险！探索神秘岛屿，解决谜题，避开陷阱，找到传说中的宝藏。',
    instructions: '使用方向键移动角色，空格键互动或跳跃。收集地图碎片和线索以解锁新区域。注意你的健康和库存管理。',
    thumbnailUrl: '/images/treasure-hunt.jpg',
    sourceUrl: 'https://github.com/adventuregames/treasurehunt',
    categories: ['adventure']
  },
  {
    id: 'dungeon-explorer',
    title: '地下城探险者',
    description: '勇敢的探险家，准备好探索充满怪物和宝藏的神秘地下城了吗？这款像素风格的冒险游戏充满了挑战和秘密。',
    instructions: '使用WASD移动，鼠标点击进行攻击或互动。E键打开物品栏，F键使用物品。探索每个房间，寻找通往下一层的钥匙。',
    thumbnailUrl: '/images/dungeon-explorer.jpg',
    sourceUrl: 'https://github.com/pixeladventure/dungeonexplorer',
    categories: ['adventure']
  }
];

export function getGamesByCategory(categoryId: string): Game[] {
  return games.filter(game => game.categories.includes(categoryId));
}

export function getGameById(id: string): Game | undefined {
  return games.find(game => game.id === id);
}

export function getCategoryById(id: string): Category | undefined {
  return categories.find(category => category.id === id);
} 